package uistore;

import org.openqa.selenium.By;

public class SearchpageUistore {

//public By tgicon = By.xpath("//a[@href='http://www.travelguru.com/']");
public By pagename = By.xpath("//*[@id='search-results']/div[1]/h2/span");







}
