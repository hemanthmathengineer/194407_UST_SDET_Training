package uistore;

import org.openqa.selenium.By;

public class HomepageUistore {
//public By from = By.id("BE_flight_origin_city");
//public By to = By.id("BE_flight_arrival_city");
//public By date = By.id("BE_flight_origin_date");
//public By dateid = By.id("06/09/2021");
//public By search = By.id("BE_flight_flsearch_btn");
//public By tgicon = By.xpath("//a[@href='http://www.travelguru.com/']");
public By search = By.id("search");
public By list = By.xpath("//*[@id='topnav_wrapper']/ul/li");
public By living = By.xpath("//*[@id='topnav_wrapper']/ul/li[2]/span");
public By display = By.xpath("//*[@id='topnav_wrapper']/ul/li[2]/div");
public By study = By.xpath("//div[@class='categories row']/a[contains(@href,'study-table?')]");
public By wishlist = By.xpath("//*[@id='header']/div[1]/div/section[3]/ul/li[3]/a");
public By smail = By.xpath("//*[@id='email_id']");
public By subscribe = By.xpath("//*[@id='nl-subscribe-footer']/div[2]/input");
public By socialmedia = By.xpath("//*[@id='footer-social']/li");
public By address =By.xpath("//*[@id='footer-links']/div[1]/div[4]/ul/li[1]");








}
