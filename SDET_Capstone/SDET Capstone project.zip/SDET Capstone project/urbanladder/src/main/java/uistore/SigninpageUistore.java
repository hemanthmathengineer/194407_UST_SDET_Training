package uistore;

import org.openqa.selenium.By;

public class SigninpageUistore {

//public By tgicon = By.xpath("//a[@href='http://www.travelguru.com/']");
public By mailid = By.xpath("//*[@id='spree_user_email']");
public By validlabel = By.xpath("//*[@id='signup_form']/label");
public By password = By.xpath("//input[@id='spree_user_password'][2]");











}
